import math

# Define DeliveryLocation class to represent a delivery location
class DeliveryLocation:
    def __init__(self, id, x, y, priority):
        self.id = id
        self.x = x
        self.y = y
        self.priority = priority
        self.delivered = False

    def distance_to(self, other):
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)

# Greedy algorithm for initial route selection
def select_initial_route(delivery_locations):
    current_location = delivery_locations[0]
    route = [current_location]
    current_location.delivered = True

    while len(route) < len(delivery_locations):
        min_dist = float('inf')
        next_location = None
        for loc in delivery_locations:
            if not loc.delivered:
                dist = current_location.distance_to(loc)
                if dist < min_dist:
                    min_dist = dist
                    next_location = loc
        next_location.delivered = True
        route.append(next_location)
        current_location = next_location

    return route

# Backtracking for rerouting on unexpected events
def reroute_on_unexpected_event(current_route, unexpected_event):
    # Your backtracking logic to reroute based on the unexpected event
    return current_route  # For simplicity, no actual rerouting is performed in this example

# Sample usage
delivery_locations = [
    DeliveryLocation(1, 0, 0, 1),
    DeliveryLocation(2, 1, 2, 5),
    DeliveryLocation(3, 3, 1, 4),
    DeliveryLocation(4, 2, 0, 3),
    DeliveryLocation(5, 1, 0, 2),
    DeliveryLocation(6, 1, 5, 6)

]

# Select initial route using greedy algorithm
initial_route = select_initial_route(delivery_locations)

# Simulate an unexpected event
unexpected_event_occurs = True
unexpected_event = {}  # Placeholder for unexpected event details

if unexpected_event_occurs:
    # Reroute based on unexpected event using backtracking logic
    new_route = reroute_on_unexpected_event(initial_route, unexpected_event)
    initial_route = new_route

# Display the final route
print("Final Delivery Route:")
for loc in initial_route:
    print(f"Location {loc.id} -> Priority: {loc.priority}")
